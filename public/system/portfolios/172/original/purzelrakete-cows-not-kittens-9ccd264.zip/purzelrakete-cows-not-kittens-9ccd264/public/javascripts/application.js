function milkingFeedback() {
  var head = $$("h1").first();
  head.update("Milking...");
  head.setStyle({ color: 'red' });
  head.pulsate();
}