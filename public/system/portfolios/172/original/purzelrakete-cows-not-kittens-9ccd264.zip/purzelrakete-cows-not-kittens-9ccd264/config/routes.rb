ActionController::Routing::Routes.draw do |map|
  map.resources :cows, :member => { :milk => :post }
end
