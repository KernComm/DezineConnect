# Be sure to restart your server when you modify this file.
Inflector.inflections do |inflect|
  inflect.irregular 'cow', 'cows'
end
