class CowsController < ApplicationController
  resource_this
  
  # milking has the side effect of causing 
  # the cow to moo. we don't want to 
  # wait for this while milking, though, 
  # it would be a terrible waste ouf our time. 
  def milk
    @cow = Cow.find(params[:id])
    @cow.milk
  end
end