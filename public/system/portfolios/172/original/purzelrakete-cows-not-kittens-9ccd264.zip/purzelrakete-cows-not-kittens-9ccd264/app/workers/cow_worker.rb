#
# handle asynchronous mooing. 
#
class CowWorker < Workling::Base
  
  # let the moo-ings begin! 
  def moo(options = {})
    cow = Cow.find(options[:id])
    cow.moo
  end
end