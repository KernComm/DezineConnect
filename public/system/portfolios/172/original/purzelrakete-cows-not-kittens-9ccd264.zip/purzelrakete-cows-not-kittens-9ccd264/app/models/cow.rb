class Cow < ActiveRecord::Base

  # TODO: SAP integration
  def milk    
    moo
  end

  # bothersome side-effect
  def moo
    CowSubsystem.moo
  end
end