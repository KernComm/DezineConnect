class CowSubsystem
  def self.moo
    `#{ RAILS_ROOT }/playsound/playsound #{ RAILS_ROOT }/assets/sounds/cow.wav`
  end
end