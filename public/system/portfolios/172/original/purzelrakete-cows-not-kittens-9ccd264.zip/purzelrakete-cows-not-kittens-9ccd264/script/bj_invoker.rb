@routing = Workling::Starling::Routing::ClassAndMethodRouting.new
message, command, args = *REXML::Text::unnormalize(STDIN).match(/(^[^ ]*) (.*)/)
options = Hash.from_xml(args)["hash"]

@routing[command].send @routing.method_name(command), options if  @routing[command]

