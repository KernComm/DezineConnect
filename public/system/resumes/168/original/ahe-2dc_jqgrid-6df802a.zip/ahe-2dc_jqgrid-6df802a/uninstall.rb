`rake jqgrid:uninstall`
