
require "ftools"

dir = "images/images"
org = "original"
thumb = "thumb"
filename  = ""
id_array = []
# get all the folders in images/images
Dir.chdir(dir) do
puts "curent dir1 is :" + Dir.pwd
id_array = Dir.glob("*")
end
puts  id_array
#count the folders
length = id_array.length
puts  length
i=0
#till the nth folder, copy the images in those folders to the specified target
while i<length 
Dir.chdir(dir+"/"+id_array[i]+"/"+org) do
puts "curent dir is :" + Dir.pwd
filename += Dir.glob("*").to_s
end
puts "filename is "+ filename
src = dir+"/"+id_array[i]+"/"+org+"/"+filename
tgt = id_array[i]+"_"+org+"_"+filename
File.copy(src,tgt)
src = dir+"/"+id_array[i]+"/"+thumb+"/"+filename
tgt = id_array[i]+"_"+thumb+"_"+filename
File.copy(src,tgt)
filename = ""
i+=1
end

